import React from 'react'

export default function App() {
  return (
    <div style={{fontFamily:'sans-serif', padding:'20px'}}>
      <h1>HelioSkin</h1>
      <p>Web en construcción — lista para tu PA4.</p>
      <ul>
        <li>PMV</li>
        <li>Catálogo</li>
        <li>Reseñas</li>
        <li>Proyecto Social</li>
      </ul>
    </div>
  )
}
